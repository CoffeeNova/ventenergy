﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Snap7;
using NLog;
using System.Threading;
using System.Diagnostics;
using System.Data.SqlClient;

namespace ventEnergy
{
    public partial class MainServerForm : Form
    {


        //private const string _ipPLC = "172.20.199.225";
        //private const int _RACK = 0;
        //private const int _SLOT = 3;
        //private const int _DEFAULT_CHECK_INTERVAL = 60000; //60000 - 1 min
        //private const string connectionString = @"Integrated Security=false; Persist Security Info=False; Initial Catalog=PIC_D_DATABASE ; Data Source=BIW01PC1; User ID=ventEnergy; Password=belsolod.ventEnergy2015";
        //private const string _DATABASENAME = "PIC_D_DATABASE"; //имя Базы данных
        //private const string _CONFtb = "ventEnergyConf"; //имя таблицы конфигурации в БД 
        //private const string _DATAtb = "ventEnergyData"; //имя таблицы данных в БД 
        struct ReadData
        {
            public const int defaultHour = 9;
            public const int defaultMinute = 00;
        }

        private bool debugBit = false;    // set true to see how to fill database
        private bool tryToConnect = false;
        private S7Client Client;
        private System.Threading.Timer readDataTimer;
        private readonly Logger log = LogManager.GetCurrentClassLogger();      
        private int checkInterval;
        private int hour;
        private int minute;
        private List<Vents> VentsData;
        

        public MainServerForm(string[] args)
        {

            InitializeComponent();
            VentsData = new List<Vents>();


            checkInterval = VentsConst._DEFAULT_CHECK_INTERVAL;
            hour = ReadData.defaultHour;
            minute = ReadData.defaultMinute;

            foreach (string arg in args)
            {
                if(arg.StartsWith("-int"))
                {
                    int i = VentsConst._DEFAULT_CHECK_INTERVAL;
                    try
                    {
                        i = Convert.ToInt32(arg.Split('=')[1]);
                    }   
                    catch
                    {
                        log.Error("Задан не числовой аргумент -int");
                        Process.GetCurrentProcess().Kill();
                    }
                    checkInterval = i;
                }
                if(arg.StartsWith("-hour"))
                {
                    int h = ReadData.defaultHour;
                    try
                    {
                        h = Convert.ToInt32(arg.Split('=')[1]);
                        if (h < 0 || h > 23)
                            throw new Exception();
                    }   
                    catch
                    {
                        log.Error("Задан не верный числовой аргумент -hour");
                        Process.GetCurrentProcess().Kill();
                    }
                    hour= h;
                }
                if (arg.StartsWith("-min"))
                {
                    int m = ReadData.defaultMinute;
                    try
                    {
                        m = Convert.ToInt32(arg.Split('=')[1]);
                        if (m < 0 || m > 59)
                            throw new Exception();
                    }
                    catch
                    {
                        log.Error("Задан не верный числовой аргумент -min");
                        Process.GetCurrentProcess().Kill();
                    }
                    minute = m;
                }

                if (arg.StartsWith("-debug"))
                {
                    debugBit = true;
                }
            }

            try
            {
                Client = new S7Client();
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                Process.GetCurrentProcess().Kill();
            }
            readDataTimer = new System.Threading.Timer(ReadDataEvent, null, 0, checkInterval);

        }

        private void ReadDataEvent(Object state)
        {
            //Stopwatch watch = new Stopwatch();
            //watch.Start();
                
            if ((hour == System.DateTime.Now.Hour &&
                   minute == System.DateTime.Now.Minute && !tryToConnect) || (debugBit && !tryToConnect))
                {
                    int tempConnected;

                    tryToConnect = false;
                    // 0 - connection successfull 
                    tempConnected = Client.ConnectTo(VentsConst._ipPLC, VentsConst._RACK, VentsConst._SLOT);
                    if (tempConnected != 0)
                    {
                        ShowError(tempConnected);
                        tryToConnect = true;
                        return;
                    }
                    else
                    {
                        new Thread(DirtyJob).Start();  
                    }

                }
                
            if (tryToConnect)
                {
                    int tempConnected;

                    tempConnected = Client.ConnectTo(VentsConst._ipPLC, VentsConst._RACK, VentsConst._SLOT);
                    if (tempConnected != 0)
                    {
                        //ShowError(tempConnected); уберем ошибку из лога, будет повторяться очень часто одинаковая
                    }
                    else
                    {
                        tryToConnect = false;
                        new Thread(DirtyJob).Start();
                    }
                
                //readDataTimer.Change( Math.Max( 0, _CHECK_INTERVAL - watch.ElapsedMilliseconds ), Timeout.Infinite );
                //watch.Stop();
            }

        }
        private void DirtyJob()
        {
            VentsTools VT = new VentsTools();
            if (VT.ReadConfigFromDB(VentsConst.connectionString, VentsConst._CONFtb, ref VentsData))
                if (ReadDataFromPLC())
                     WriteDataToDB();
        }
        //read config from ventEnergyConf.tb
        
        private bool ReadDataFromPLC()
        {
            try             
            {
                foreach(Vents vent in VentsData)
                {
                    int result;
                    byte[] buffer = new byte[2];
                    result = Client.DBRead(vent.DB, vent.startBit, vent.size, buffer);
                    if (result != 0)
                        ShowError(result);
                    else
                        vent.value = buffer[0] << 8 | buffer[1];
                }
                int discResult = Client.Disconnect();
                if (discResult != 0)
                { 
                    ShowError(discResult);
                    return false;
                }
                return true;
            }
            catch(Exception ex)
            {
                log.Error(ex.Message);
                return false;
            }
        }
        private bool WriteDataToDB()
        {
            int eventID=0;
            int lastEventID = 0;
            SqlConnection connection = new SqlConnection(VentsConst.connectionString);
            try
            {
                connection.Open();
            }
            catch (SqlException ex)
            {
                log.Error(ex.Message);
                return false;
            }
            try
            {
                //получим номер последней записи
                SqlCommand cmd = new SqlCommand("Select Top 1 eventID from " + VentsConst._DATAtb + " ORDER BY eventID DESC", connection); //команда на получение последнего номера eventID
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                if(!dr.Read())
                    lastEventID = -1;
                else
                    lastEventID = dr.GetInt32(0);

                eventID = lastEventID + 1;
                connection.Close();


                try
                {
                    connection.Open();
                }
                catch (SqlException ex)
                {
                    log.Error(ex.Message);
                    return false;
                }
                foreach(Vents vent in VentsData)
                {
                    
                    //добавим новые записи
                    cmd = new SqlCommand("Insert into " + VentsConst._DATAtb + "(eventID, date, name, value) Values (@eventID, @date, @name, @value)", connection);
                    SqlParameter param = new SqlParameter();
                    param.ParameterName = "@eventID";
                    param.Value = eventID;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);
                    eventID++;

                    param = new SqlParameter();
                    param.ParameterName = "@date";
                    param.Value = System.DateTime.Now;
                    param.SqlDbType = SqlDbType.DateTime;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@name";
                    param.Value = vent.name;
                    param.SqlDbType = SqlDbType.VarChar;
                    cmd.Parameters.Add(param);

                    param = new SqlParameter();
                    param.ParameterName = "@value";
                    param.Value = vent.value;
                    param.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(param);

                    try
                    {
                        cmd.ExecuteNonQuery(); //вставляем запись
                    }
                    catch
                    {
                        throw new Exception("Ошибка при выполнении запроса на добавление записи");
                    }
                }


                connection.Close();
                connection.Dispose();
                return true;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                connection.Close();
                connection.Dispose();
                return false;
            }
        }
        private void ShowError(int Result)
        {
            // This function returns a textual explaination of the error code
            log.Error(Client.ErrorText(Result));
        }
        private void Form1_Shown(Object sender, EventArgs e)
        {

            this.Hide();

        }
    }
    public class Vents
    {
        public int id { get; set; }         //номер
        public string name { get; set; }    //название 
        public int DB { get; set; }         //номер блока данных
        public int startBit { get; set; }   //нормер переменной в DB
        public int size { get; set; }       //размер переменной в байтах
        public int value {get; set; }       //значение
        public string descr { get; set; }   //описание
        public DateTime date { get; set; }
    }
    public class VentsTools
    {
        private readonly Logger log = LogManager.GetCurrentClassLogger();

        public bool ReadConfigFromDB(string connectionString, string configTable, ref List<Vents> VentsData)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                connection.Open();
            }
            catch (SqlException ex)
            {
                log.Error(ex.Message);
                return false;
            }

            try
            {
                SqlCommand cmd = new SqlCommand("Select * From " + configTable, connection);
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                List<Vents> ventslist = new List<Vents>();
                while (dr.Read())
                {
                    ventslist.Add(new Vents { id = dr.GetInt16(0), name = dr.GetValue(1).ToString(), DB = dr.GetInt16(2), startBit = dr.GetInt32(3), size = (int)dr.GetByte(4), value = 0, descr = dr.GetValue(5).ToString() });
                }
                connection.Close();
                connection.Dispose();
                VentsData = ventslist;
                return true;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                connection.Close();
                connection.Dispose();
                return false;
            }

        }
        public bool ReadValuesFromDB(string connectionString, string configTable, ref List<Vents> VentsData)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                connection.Open();
            }
            catch (SqlException ex)
            {
                log.Error(ex.Message);
                return false;
            }

            try
            {
                SqlCommand cmd = new SqlCommand("Select * From " + configTable, connection);
                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                List<Vents> ventslist = new List<Vents>();
                while (dr.Read())
                {
                    ventslist.Add(new Vents { id = dr.GetInt16(0), name = dr.GetValue(1).ToString(), DB = dr.GetInt16(2), startBit = dr.GetInt32(3), size = (int)dr.GetByte(4), value = 0, descr = dr.GetValue(5).ToString() });
                }
                connection.Close();
                connection.Dispose();
                VentsData = ventslist;
                return true;
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
                connection.Close();
                connection.Dispose();
                return false;
            }
        }
        public bool FillVentsData(ref List<Vents> VentsData)
        {
            bool readCfgResult = false;
            VentsTools VT = new VentsTools();

            readCfgResult = ReadConfigFromDB(VentsConst.connectionString, VentsConst._CONFtb, ref VentsData);
            if (!readCfgResult)
                MessageBox.Show("Нет подключения к базе данных, проверьте настройки сети");
            return readCfgResult;
        }
    }

    public static class VentsConst
    {
        public  const string _ipPLC = "172.20.199.225";
        public  const int _RACK = 0;
        public  const int _SLOT = 3;
        public  const int _DEFAULT_CHECK_INTERVAL = 60000; //60000 - 1 min
        public  const string connectionString = @"Integrated Security=false; Persist Security Info=False; Initial Catalog=PIC_D_DATABASE ; Data Source=BIW01PC1; User ID=ventEnergy; Password=belsolod.ventEnergy2015";
        public  const string _DATABASENAME = "PIC_D_DATABASE"; //имя Базы данных
        public  const string _CONFtb = "ventEnergyConf"; //имя таблицы конфигурации в БД 
        public  const string _DATAtb = "ventEnergyData"; //имя таблицы данных в БД 
    }
}
